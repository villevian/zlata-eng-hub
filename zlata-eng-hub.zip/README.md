# zlata-eng-hub

Hub для подготовки Златы к экзамену **Identity A2–B1 (Units 1–12)**.
Прогресс по чек-листу сохраняется в Supabase автоматически.

## Структура (сейчас и план)
- `index.html` — **Check List** (готов)
- `course-book.html` — Course Book (скоро)
- `workbook.html` — Workbook (скоро)
- `help.html` — Help (скоро)
- `bg.png` — фон (общий для всех страниц)
- `supabase.sql` — миграция (уже применена)

## Запуск (GitHub Pages)
1. Залить все файлы в корень репозитория.
2. **Settings → Pages → Source: Deploy from a branch → main / root → Save**.
3. Откроется `https://villevian.github.io/zlata-eng-hub/`.

База, ключ и студент уже зашиты в `index.html`. Ничего настраивать не нужно.
